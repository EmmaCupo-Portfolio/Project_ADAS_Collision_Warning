#  ADAS Collision Warning Explorer & Interactive Telemetry Dashboard

**Autrice:** Studentessa di Ingegneria Meccanica  
**Strumenti:** MATLAB, MATLAB App Designer / UI, `matlab.unittest`  
**Ambito:** Ingegneria Automotive, Sistemi ADAS (Advanced Driver Assistance Systems), Cinematica del Veicolo

---

##  Panoramica del Progetto
Il progetto sviluppa un sistema di valutazione automatizzata del rischio di collisione frontale (*Forward Collision Warning - FCW*) per veicoli autonomi o assistiti, basato sull'elaborazione di dati sintetici da sensori radar e sulla cinematica del veicolo.

L'algoritmo filtra i bersagli rilevati dal radar per identificare il veicolo antecedente nella propria corsia (*Lead Vehicle*), calcola il tempo all'impatto (**Time-To-Collision - TTC**) e aggiorna in tempo reale una dashboard grafica interattiva.

---

##  Fisica del Sistema & Logica ADAS

### 1. Filtraggio Spaziale in Corsia (*In-Lane Filtering*)
Dati i confini trasversali della corsia $Y_{\text{left}} = +1.62\text{ m}$ e $Y_{\text{right}} = -1.62\text{ m}$ (larghezza corsia $3.24\text{ m}$), un bersaglio radar generico $(X_i, Y_i)$ viene considerato in corsia se:
$$-\frac{W_{\text{lane}}}{2} \le Y_i \le \frac{W_{\text{lane}}}{2}$$

### 2. Calcolo Cinematico del Time-To-Collision (TTC)
Identificato il veicolo antecedente più vicino $X_{\text{lead}}$, dato il valore di velocità di avvicinamento (*Closing Speed*) $v_{\text{rel}} > 0$:
$$\text{TTC} = \frac{X_{\text{lead}}}{v_{\text{rel}}} \quad [\text{secondi}]$$
Se $v_{\text{rel}} \le 0$ (veicolo in allontanamento o a pari velocità), $\text{TTC} = \infty$.

### 3. Classificazione delle Soglie di Sicurezza
*  **WARNING ($\text{TTC} \le 2.0\text{ s}$):** Rischio imminente di impatto.
*  **CAUTION ($2.0\text{ s} < \text{TTC} \le 4.0\text{ s}$):** Veicolo in prossimità, attenzione richiesta.
*  **NORMAL ($\text{TTC} > 4.0\text{ s}$ o corsia libera):** Condizioni di marcia sicura.

---

##  Architettura del Codice
Il repository è strutturato nei seguenti moduli:

1. `main_analysis.m`: Script principale per la simulazione e la generazione del profilo temporale del TTC su 204 frame.
2. `analyzeLeadVehicle.m`: Funzione modularizzata che esegue il filtro di corsia, il calcolo cinematico del TTC e la classificazione del rischio.
3. `analyzeLeadVehicleTest.m`: Suite di **Unit Test automatizzati** (`matlab.unittest.TestCase`) per verificare:
   * Correttezza del calcolo del TTC in condizione di Warning.
   * Scarto dei veicoli vicini ma presenti nelle corsie adiacenti (prevenzione falsi allarmi).
   * Gestione di corsia vuota.
4. `adas_dashboard_app.m`: Interfaccia grafica interattiva (UI) con vista dall'alto (*Bird's-Eye View*), grafico temporale del TTC e slider di scorrimento in tempo reale.

---

##  Come Eseguire il Progetto
1. Aprire MATLAB o MATLAB Online.
2. Posizionarsi nella cartella del progetto.
3. **Esecuzione dell'App Interattiva:**
   ```matlab
   adas_dashboard_app