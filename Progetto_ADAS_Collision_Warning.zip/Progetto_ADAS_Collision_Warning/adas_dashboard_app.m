function adas_dashboard_app()
%% MODULO 4: Dashboard Interattiva ADAS - Collision Warning Explorer
% Progetto: Analisi Rischio Collisione e Dashboard Interattiva

    %% 1. Parametri e Generazione Dati
    numFrames = 204;
    dt = 0.05;
    timeVec = (0:numFrames-1)*dt;
    laneWidth = 3.24;
    leftBoundary = laneWidth/2;
    rightBoundary = -laneWidth/2;

    % Inizializzazione vettori
    sensorData = struct();
    ttcVec = zeros(1, numFrames);
    riskStatus = strings(1, numFrames);
    leadDistVec = zeros(1, numFrames);
    closingVVec = zeros(1, numFrames);

    rng(42);
    for f = 1:numFrames
        t = timeVec(f);
        x1 = 50 - 12*t + 0.4*t^2; y1 = 0.1; v1 = 12 - 0.8*t;
        x2 = 35 + 2*t; y2 = 2.5; v2 = -2;
        x3 = 60 + 5*t; y3 = -2.8; v3 = -5;

        X = [x1, x2, x3];
        Y = [y1, y2, y3];
        V = [v1, v2, v3];

        sensorData(f).X = X;
        sensorData(f).Y = Y;

        % Richiamo della funzione testata nel Modulo 3
        [leadDistVec(f), closingVVec(f), ttcVec(f), riskStatus(f)] = analyzeLeadVehicle(X, Y, V, laneWidth);
    end

    %% 2. Creazione della Finestra dell'Interfaccia Grafica (UI)
    fig = uifigure('Name', 'ADAS Collision Warning Explorer - Dashboard', 'Position', [100 100 900 600]);

    % Layout a griglia 2x2 (chiamata appLayout per non sovrascrivere il comando grid!)
    appLayout = uigridlayout(fig, [2 2]);
    appLayout.RowHeight = {'1x', 110};
    appLayout.ColumnWidth = {'1x', '1x'};

    % Grafico 1: Bird's-Eye View (in alto a sinistra)
    axBEV = uiaxes(appLayout);
    axBEV.Layout.Row = 1;
    axBEV.Layout.Column = 1;

    % Grafico 2: Profilo TTC nel Tempo (in alto a destra)
    axTTC = uiaxes(appLayout);
    axTTC.Layout.Row = 1;
    axTTC.Layout.Column = 2;
    plot(axTTC, timeVec, ttcVec, 'b-', 'LineWidth', 1.5);
    hold(axTTC, 'on'); 
    grid(axTTC, 'on');
    yline(axTTC, 2, 'r--', 'Warning (2s)');
    yline(axTTC, 4, 'm--', 'Caution (4s)');
    title(axTTC, 'Profilo Temporale TTC');
    xlabel(axTTC, 'Tempo (s)'); ylabel(axTTC, 'TTC (s)');
    ylim(axTTC, [0 12]);

    % Pallino rosso segnaposto per il frame corrente
    hMarker = plot(axTTC, timeVec(1), ttcVec(1), 'ro', 'MarkerFaceColor', 'r', 'MarkerSize', 8);

    % Pannello 1: Slider di Controllo (in basso a sinistra)
    pnlControl = uipanel(appLayout, 'Title', 'Controllo Sequenza Temporale');
    pnlControl.Layout.Row = 2;
    pnlControl.Layout.Column = 1;

    uilabel(pnlControl, 'Text', 'Trascina lo Slider per cambiare Frame:', 'Position', [20 50 300 22], 'FontWeight', 'bold');
    sld = uislider(pnlControl, 'Limits', [1 numFrames], 'Value', 1, 'Position', [20 30 350 3]);
    sld.MajorTicks = 1:50:204;
    
    % Collega lo spostamento dello slider alla funzione di aggiornamento
    sld.ValueChangingFcn = @(src, event) updatePlots(round(event.Value));
    sld.ValueChangedFcn = @(src, event) updatePlots(round(event.Value));

    % Pannello 2: Indicatori Telemetrici ADAS (in basso a destra)
    pnlInfo = uipanel(appLayout, 'Title', 'Telemetria e Stato di Rischio ADAS');
    pnlInfo.Layout.Row = 2;
    pnlInfo.Layout.Column = 2;

    lblInfoText = uilabel(pnlInfo, 'Text', '', 'Position', [15 10 380 70], 'FontSize', 11, 'FontWeight', 'bold');

    % Disegno iniziale al frame 1
    updatePlots(1);

    %% 3. Funzione Interna di Aggiornamento Dinamico
    function updatePlots(f)
        % Ridisegna la Vista dall'Alto (BEV)
        cla(axBEV);
        hold(axBEV, 'on'); 
        grid(axBEV, 'on');

        % Corsie stradali
        plot(axBEV, [-10 80], [leftBoundary leftBoundary], 'k--', 'LineWidth', 1.5);
        plot(axBEV, [-10 80], [rightBoundary rightBoundary], 'k--', 'LineWidth', 1.5);

        % Nostra auto (Ego)
        rectangle(axBEV, 'Position', [-2 -0.9 4 1.8], 'FaceColor', [0.2 0.6 1], 'EdgeColor', 'b');
        text(axBEV, 0, 0, 'Ego', 'HorizontalAlignment', 'center', 'Color', 'white', 'FontWeight', 'bold');

        % Tutti i target radar
        X = sensorData(f).X;
        Y = sensorData(f).Y;
        scatter(axBEV, X, Y, 70, 'r', 'filled');

        % Evidenzia l'auto in corsia se presente
        if ~isinf(ttcVec(f))
            inLane = find(Y >= rightBoundary & Y <= leftBoundary);
            [~, idx] = min(X(inLane));
            leadIdx = inLane(idx);
            scatter(axBEV, X(leadIdx), Y(leadIdx), 150, 'g', 'LineWidth', 2.5);
        end

        title(axBEV, sprintf('Bird''s-Eye View - Frame %d / %d', f, numFrames));
        xlabel(axBEV, 'Distanza X (m)'); ylabel(axBEV, 'Offset Y (m)');
        xlim(axBEV, [-5 70]); ylim(axBEV, [-5 5]);

        % Aggiorna la posizione del segnaposto nel grafico TTC
        hMarker.XData = timeVec(f);
        hMarker.YData = min(ttcVec(f), 12);

        % Aggiorna il testo informativo
        lblInfoText.Text = sprintf(['Frame: %d | Tempo: %.2f s\n' ...
                                    'Distanza Veicolo Davanti: %.2f m\n' ...
                                    'Velocita di Avvicinamento: %.2f m/s\n' ...
                                    'TTC: %.2f s  ---> STATO ADAS: %s'], ...
                                    f, timeVec(f), leadDistVec(f), closingVVec(f), ttcVec(f), riskStatus(f));
    end
end