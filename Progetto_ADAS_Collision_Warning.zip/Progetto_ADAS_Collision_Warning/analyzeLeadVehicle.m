function [leadDist, closingV, ttc, status] = analyzeLeadVehicle(X, Y, V, laneWidth)
% ANALYZELEADVEHICLE Calcola distanza, closing speed, TTC e stato di rischio
% per l'oggetto antecedente più vicino presente nella corsia di marcia.

%Limiti trasversali corsia:
leftBoundary = laneWidth / 2;
rightBoundary = -laneWidth / 2;

% Trova gli indici dei target dentro la corsia
inLaneIndices = find(Y >= rightBoundary & Y <= leftBoundary);

if isempty(inLaneIndices)
    leadDist = Inf;
    closingV = 0;
    ttc = Inf;
    status = "Normal";
else
    % Trova il target con la distanza X minore (più vicino a noi)
    [leadDist, idxMin] = min(X(inLaneIndices));
    leadIdx = inLaneIndices(idxMin);
    closingV = V(leadIdx);

    % Calcolo cinematico del Time-To-Collision (TTC)
    if closingV > 0
        ttc = leadDist / closingV;
    else
        ttc = Inf;
    end

    % Classificazione del Rischio
    if ttc <= 2
        status = "Warning";
    elseif ttc <= 4
        status = "Caution";
    else
        status = "Normal";
    end
end
end