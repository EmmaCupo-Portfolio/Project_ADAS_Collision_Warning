classdef analyzeLeadVehicleTest < matlab.unittest.TestCase
    % ANALYZELEADVEHICLETEST Classe di Unit Test per il sistema ADAS

    properties
        LaneWidth = 3.24; % Larghezza corsia di prova (metri)
    end

    methods (Test)

        function testWarningCondition(testCase)
            % Test Scenario 1: Veicolo in corsia vicinissimo e veloce (Rischio Imminente -> WARNING)
            X = [15, 40];      % Auto 1 a 15m, Auto 2 a 40m
            Y = [0.1, 2.5];    % Auto 1 in corsia (+0.1m), Auto 2 fuori corsia (+2.5m)
            V = [10, 5];       % Closing speed 10 m/s -> TTC = 15/10 = 1.5 secondi

            [dist, closingV, ttc, status] = analyzeLeadVehicle(X, Y, V, testCase.LaneWidth);

            % Verifiche automatizzate (Assertions)
            testCase.verifyEqual(dist, 15);
            testCase.verifyEqual(ttc, 1.5);
            testCase.verifyEqual(status, "Warning");
        end

        function testIgnoreAdjacentLane(testCase)
            % Test Scenario 2: Veicolo vicinissimo MA nella corsia adiacente (Deve essere IGNORATO)
            X = [8, 50];       % Auto 1 a soli 8 metri di distanza, Auto 2 a 50m
            Y = [2.8, -0.2];   % Auto 1 è fuori corsia (+2.8m), Auto 2 è in corsia (-0.2m)
            V = [15, 5];       % Closing speed

            [dist, closingV, ttc, status] = analyzeLeadVehicle(X, Y, V, testCase.LaneWidth);

            % Deve selezionare l'Auto 2 a 50m, IGNORANDO l'Auto 1 vicina ma fuori corsia!
            testCase.verifyEqual(dist, 50);
            testCase.verifyEqual(status, "Normal");
        end

        function testEmptyLane(testCase)
            % Test Scenario 3: Nessun veicolo presente nella nostra corsia
            X = [20, 30];
            Y = [3.0, -3.0];   % Entrambe le auto sono nelle corsie laterali
            V = [5, 5];

            [dist, closingV, ttc, status] = analyzeLeadVehicle(X, Y, V, testCase.LaneWidth);

            testCase.verifyEqual(dist, Inf);
            testCase.verifyEqual(status, "Normal");
        end

    end
end