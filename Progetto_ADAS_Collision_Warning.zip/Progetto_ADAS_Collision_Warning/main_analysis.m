%% MODULO 1: Generazione Dati Sensoriali & Filtraggio Corsia (ADAS)

clear; clc; close all;

%% 1. Definizione Parametri Sensore e Strada

numFrames = 204;              % 204 frame temporali
dt = 0.05;                    % Campionamento temporale (50 ms tra i frame)
timeVec = (0:numFrames-1)*dt; % Vettore tempo in secondi (da 0 a 10.15 s)

% Limiti di corsia (in metri rispetto al centro della nostra auto):
laneWidth = 3.24;             % Larghezza totale corsia (metri)
leftBoundary = laneWidth/2;   % Confine sinistro (+1.62 m)
rightBoundary = -laneWidth/2; % Confine destro (-1.62 m)

fprintf('=== AVVIO ANALISI SISTEMA ADAS ===\n');
fprintf('Numero Frame da analizzare: %d\n', numFrames);
fprintf('Larghezza corsia impostata: %.2f m (Sinistra: +%.2f m, Destra: %.2f m)\n\n', ...
    laneWidth, leftBoundary, rightBoundary);

%% 2. Generazione Scenario Sintetico Radar

% Creiamo un target (auto davanti a noi) che si avvicina gradualmente
egoSpeed = 25; % Nostra velocità (m/s ~ 90 km/h)

% Posizioni iniziali dei target attorno al veicolo (in coordinate X, Y)
% X = posizione longitudinale (distanza frontale in metri)
% Y = posizione trasversale (offset laterale in metri)
rng(42); % Seed fisso per riproducibilità dei dati

% Inizializzazione struttura dati per i 204 frame
sensorData = struct();

for f = 1:numFrames
    t = timeVec(f);

    % Auto 1 (Veicolo in corsia davanti a noi): parte da 50m e rallenta
    x1 = 50 - 12*t + 0.4*t^2; 
    y1 = 0.1; % Leggermente a destra del centro ma dentro la corsia (+0.1 m)
    v_rel1 = 12 - 0.8*t; % Velocità di avvicinamento (closing speed in m/s)

    % Auto 2 (Veicolo in corsia adiacente sinistra - da ignorare per il rischio collisione)
    x2 = 35 + 2*t;
    y2 = 2.5; % Offset laterale +2.5 m (fuori dalla corsia di marcia!)
    v_rel2 = -2;

    % Auto 3 (Veicolo in corsia adiacente destra - da ignorare)
    x3 = 60 + 5*t;
    y3 = -2.8; % Offset laterale -2.8 m (fuori corsia)
    v_rel3 = -5;

    % Salva i target del frame corrente
    sensorData(f).Frame = f;
    sensorData(f).Time = t;
    sensorData(f).RadarDetections.X = [x1, x2, x3];
    sensorData(f).RadarDetections.Y = [y1, y2, y3];
    sensorData(f).RadarDetections.ClosingSpeed = [v_rel1, v_rel2, v_rel3];
end

disp('Dati sensoriali generati con successo!');

%% 3. Analisi del Primo Frame (Visualizzazione Bird's-Eye View)

frameToInspect = 1; % Analizziamo il frame 1
currentFrame = sensorData(frameToInspect);

X_all = currentFrame.RadarDetections.X;
Y_all = currentFrame.RadarDetections.Y;
V_all = currentFrame.RadarDetections.ClosingSpeed;

% Filtro spaziale: Trova quali target hanno Y compresa tra rightBoundary e leftBoundary
inLaneIndices = find(Y_all >= rightBoundary & Y_all <= leftBoundary);

% Seleziona tra i target in corsia quello con la distanza X minore (più vicino a noi)
[minDistance, idxMin] = min(X_all(inLaneIndices));
leadVehicleIdx = inLaneIndices(idxMin);

leadX = X_all(leadVehicleIdx);
leadY = Y_all(leadVehicleIdx);
leadV = V_all(leadVehicleIdx);

fprintf('--- RISULTATI FRAME %d ---\n', frameToInspect);
fprintf('Target totali rilevati dal radar: %d\n', length(X_all));
fprintf('Target presenti nella nostra corsia: %d\n', length(inLaneIndices));
fprintf('Veicolo antecedente (Lead Vehicle): Distanza = %.2f m, Closing Speed = %.2f m/s\n\n', ...
    leadX, leadV);

%% 4. Grafico Bird's-Eye View

figure('Name', 'Bird-Eye View ADAS - Frame 1', 'NumberTitle', 'off');
hold on; grid on; axis equal;

% Disegna le linee di corsia
plot([-10, 80], [leftBoundary, leftBoundary], 'k--', 'LineWidth', 2);  % Corsia Sinistra
plot([-10, 80], [rightBoundary, rightBoundary], 'k--', 'LineWidth', 2);% Corsia Destra
plot([-10, 80], [0, 0], 'g:', 'LineWidth', 1);                         % Centro corsia

% Disegna la nostra auto (Ego Vehicle) a coordinate (0,0)
rectangle('Position', [-2, -0.9, 4, 1.8], 'FaceColor', [0.2 0.6 1], 'EdgeColor', 'b', 'LineWidth', 1.5);
text(0, 0, 'Ego Vehicle', 'HorizontalAlignment', 'center', 'FontWeight', 'bold', 'Color', 'white');

% Disegna tutti i target radar (Punti rossi)
scatter(X_all, Y_all, 80, 'r', 'filled', 'DisplayName', 'Target Radar Fuori Corsia');

% Evidenzia il Lead Vehicle in Corsia (Cerchio Giallo/Verde gigante)
scatter(leadX, leadY, 180, 'g', 'LineWidth', 2.5, 'DisplayName', 'Lead Vehicle (In-Lane)');
text(leadX, leadY+0.6, sprintf('Lead (%.1fm)', leadX), 'FontWeight', 'bold', 'Color', 'green');

xlabel('Distanza Longitudinale X (metri)');
ylabel('Offset Laterale Y (metri)');
title(sprintf('Vista dall''alto (Bird''s-Eye View) - Frame %d', frameToInspect));
legend('Location', 'northeastoutside');
xlim([-5, 70]);
ylim([-5, 5]);



%% MODULO 2: Calcolo TTC e Classificazione del Rischio su tutti i 204 Frame
ttcVec = zeros(1, numFrames);       % Vettore per salvare il TTC di ogni frame
riskStatus = strings(1, numFrames); % Vettore per salvare lo stato di rischio ("Normal", "Caution", "Warning")

for f = 1:numFrames
    X_f = sensorData(f).RadarDetections.X;
    Y_f = sensorData(f).RadarDetections.Y;
    V_f = sensorData(f).RadarDetections.ClosingSpeed;

    % Filtro corsia: seleziona i target dentro la corsia
    inLane = find(Y_f >= rightBoundary & Y_f <= leftBoundary);

    if isempty(inLane)
        ttcVec(f) = Inf; % Nessun veicolo in corsia -> rischio zero (TTC infinito)
        riskStatus(f) = "Normal";
    else
        % Trova il target più vicino in corsia
        [minDist, idx] = min(X_f(inLane));
        leadIdx = inLane(idx);
        distX = X_f(leadIdx);
        closingV = V_f(leadIdx);

        % Formula Fisica del TTC (Distanza / Velocità di avvicinamento)
        if closingV > 0
            ttcVec(f) = distX / closingV;
        else
            ttcVec(f) = Inf; % Se l'auto davanti si allontana o va alla nostra stessa velocità
        end

        % Soglie di Rischio ADAS
        if ttcVec(f) <= 2
            riskStatus(f) = "Warning"; % Rischio imminente
        elseif ttcVec(f) <= 4
            riskStatus(f) = "Caution"; % Attenzione
        else
            riskStatus(f) = "Normal";  % Sicurezza
        end
    end
end

% Stampa riassuntiva nella Command Window
fprintf('--- ANALISI COMPLETA DEI 204 FRAME ---\n');
fprintf('Frame in stato WARNING (TTC <= 2s): %d\n', sum(riskStatus == "Warning"));
fprintf('Frame in stato CAUTION (2s < TTC <= 4s): %d\n', sum(riskStatus == "Caution"));
fprintf('Frame in stato NORMAL (TTC > 4s): %d\n\n', sum(riskStatus == "Normal"));

%% Grafico Profilo Temporale TTC e Soglie di Rischio
figure('Name', 'Profilo Temporale Time-To-Collision (TTC)', 'NumberTitle', 'off');
plot(timeVec, ttcVec, 'b-', 'LineWidth', 2, 'DisplayName', 'TTC Calcolato');
hold on; grid on;

% Linee orizzontali di soglia
yline(2, 'r--', 'Soglia Warning (2s)', 'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left');
yline(4, 'm--', 'Soglia Caution (4s)', 'LineWidth', 1.5, 'LabelHorizontalAlignment', 'left');

xlabel('Tempo (secondi)');
ylabel('Time-To-Collision TTC (secondi)');
title('Valutazione del Rischio di Collisione ADAS nel Tempo');
ylim([0, 10]);
legend('Location', 'northeast');